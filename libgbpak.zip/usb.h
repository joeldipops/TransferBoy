/*
 * File:   fifo.h
 * Author: KRIK
 *
 * Created on 22 ������ 2011 �., 20:46
 */

#ifndef _FIFO_H
#define	_FIFO_H

#include "types.h"
u8 usbListener();


#endif	/* _FIFO_H */

